package com.example.my.tabs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.my.R
import com.example.my.Routes
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KayitEkrani(navController: NavHostController) {

    val koyu = Color(0xFF181831)
    val faculties = listOf("Bilgisayar ve Bilişim Bilimleri Fakültesi", "İletişim Fakültesi")
    val departments = mapOf(
        "Bilgisayar ve Bilişim Bilimleri Fakültesi" to listOf(
            "Bilgi Güvenliği Teknolojisi Bölümü", "Bilişim Sistemleri Ve Teknolojileri Bölümü",
            "Yazılım Geliştirme Bölümü", "Yönetim Bilişim Sistemleri Bölümü"
        ),
        "İletişim Fakültesi" to listOf(
            "Gazeticilik Bölümü",
            "Görsel İletişim Tasarımı Bölümü",
            "Radyo Televizyon ve Sinema Bölümü",
            "Reklam Tasarımı ve İletişim bölümü",
            "Halkla İlişkiler ve Tanıtım Bölümü"
        )
    )


    var ad by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var selectedFaculty by remember { mutableStateOf<String?>(null) }
    var selectedDepartment by remember { mutableStateOf<String?>(null) }
    val beyaz = Color(0xFFFFFFFF)
    var hatirla by remember { mutableStateOf(false) }
    val mavi  = Color(0xFF8186B5)

    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.oturum),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Spacer(modifier = Modifier.height(160.dp))
            TextField(
                value = ad,
                onValueChange = { ad = it },
                label = { Text("Ad ve Soyad") },
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Next
                ),
                singleLine = true,
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp)
                    .background(beyaz),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.Black,
                    focusedBorderColor = koyu,
                    unfocusedBorderColor = koyu)
            )


            // E-posta geçerliliğini ve uzantı kontrolu
            fun isValidEmail(email: String): Boolean {
                val emailRegex = "^[A-Za-z](.*)(@std.yeditepe.edu.tr)\$"
                return email.matches(emailRegex.toRegex())
            }
            var isHintDisplayed by remember { mutableStateOf(true) }
            TextField(
                value = email,
                onValueChange = {
                    email = it
                    isHintDisplayed = it.isEmpty()
                },
                placeholder = {
                    if (isHintDisplayed) {
                        Text("E-mail")
                    }
                },
                textStyle = LocalTextStyle.current.copy(color = if (isHintDisplayed) Color.Gray else Color.Black),
                singleLine = true,
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),

                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .onFocusChanged {
                        isHintDisplayed = !it.isFocused && email.isEmpty()
                    }
                    .background(beyaz),colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.Black,
                    focusedBorderColor = koyu,
                    unfocusedBorderColor = koyu)
            )



            var sifre by remember { mutableStateOf("") }
            var sifreGorunur1 by remember { mutableStateOf(false) }

            // Şifre TextField'ı için onNext özelliği (İkonlar korunmuş)
            TextField(
                value = sifre,
                onValueChange = { sifre = it },
                visualTransformation = if (sifreGorunur1) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),
                singleLine = true, // Tek satırlı olmasını sağlar
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp).background(beyaz),colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.Black,
                    focusedBorderColor = koyu,
                    unfocusedBorderColor = koyu) ,
                label = { Text("Şifre") },
                trailingIcon = {
                    val image =
                        if (sifreGorunur1) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (sifreGorunur1) "Şifreyi Gizle" else "Şifreyi Göster"
                    IconButton(onClick = { sifreGorunur1 = !sifreGorunur1 }) {
                        Icon(imageVector = image, contentDescription = description)
                    }
                }
            )


            Text(
                text = "Şifreniz en az bir özel karakter içermeli ve en az 8 karakter olmalıdır.",

                textAlign = TextAlign.Left,
                color = Color.Black ,
                fontSize = 10.sp
            )

            var sifre2 by remember { mutableStateOf("") }
            var sifreGorunur2 by remember { mutableStateOf(false) }

            TextField(
                value = sifre2,
                onValueChange = { sifre2 = it },
                visualTransformation = if (sifreGorunur2) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),
                singleLine = true, // Tek satırlı olmasını sağlar
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp).background(beyaz),colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.Black,
                    focusedBorderColor = koyu,
                    unfocusedBorderColor = koyu) ,
                label = { Text("Şifre Tekrar") },
                trailingIcon = {
                    val image =
                        if (sifreGorunur1) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (sifreGorunur1) "Şifreyi Gizle" else "Şifreyi Göster"
                    IconButton(onClick = { sifreGorunur1 = !sifreGorunur1 }) {
                        Icon(imageVector = image, contentDescription = description)
                    }
                }
            )

            var isDepartmentFocused by remember { mutableStateOf(false) }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                var isFacultyExpanded by remember { mutableStateOf(false) }

                // Fakulte Dropdown
                OutlinedTextField(
                    value = selectedFaculty ?: "",
                    onValueChange = { newText ->
                        selectedFaculty = newText
                        selectedDepartment = null
                    },
                    label = { Text("Fakülte") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    readOnly = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    trailingIcon = {
                        IconButton(onClick = { isFacultyExpanded = true }) {
                            Icon(Icons.Filled.ArrowDropDown, "İşaret")
                        }
                    },
                    keyboardActions = KeyboardActions(
                        onNext = {
                            isFacultyExpanded = true
                            // Move focus to department dropdown on pressing Enter
                            if (selectedFaculty?.isNotBlank() == true) {
                                focusManager.moveFocus(FocusDirection.Down)
                            }
                        }
                    )
                )

                DropdownMenu(
                    expanded = isFacultyExpanded,
                    onDismissRequest = { isFacultyExpanded = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    faculties.forEach { faculty ->
                        DropdownMenuItem(onClick = {
                            selectedFaculty = faculty
                            isFacultyExpanded = false
                        }, faculty)
                    }
                }
            }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                var isDepartmentExpanded by remember { mutableStateOf(false) }

                OutlinedTextField(
                    value = selectedDepartment ?: "",
                    onValueChange = { newText -> selectedDepartment = newText },
                    label = { Text("Bölüm") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    readOnly = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    trailingIcon = {
                        IconButton(onClick = { isDepartmentExpanded = true }) {
                            Icon(Icons.Filled.ArrowDropDown, "İşaret")
                        }
                    }
                )

                DropdownMenu(
                    expanded = isDepartmentExpanded,
                    onDismissRequest = { isDepartmentExpanded = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    departments[selectedFaculty]?.forEach { department ->
                        DropdownMenuItem(onClick = {
                            selectedDepartment = department
                            isDepartmentExpanded = false
                        }, department)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,

                ) {
                Checkbox(
                    checked = hatirla,
                    onCheckedChange = { hatirla = it },
                    modifier = Modifier.padding(end = 4.dp),
                    colors = CheckboxDefaults.colors(
                        checkedColor = Color.Black,
                        uncheckedColor = Color.Black
                    )
                )
                Text(
                    "Kişisel verilerime ilişkin Aydınlatma Metni’ni okudum ve onaylıyorum.",
                    fontSize = 9.sp,
                    color = Color.Black
                )
            }


            // Kayıt Ol Butonu
            Button(
                onClick = {
                    // Burada kayıt işlemini gerçekleştiricez sonra
                    //val context = LocalContext.current
                    //Toast.makeText(context, "Kayıt işlemi başarıyla tamamlandı", Toast.LENGTH_SHORT).show()
                    navController.navigate(Routes.Mail.route)
                },
                colors = ButtonDefaults.buttonColors(
                    koyu,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Text("Hesap Oluştur")
            }
        }
    }
}

@Composable
fun DropdownMenuItem(onClick: () -> Unit, faculty: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.CenterStart
    ) {
        Text(faculty)
    }
}


@Preview
@Composable
fun KayitEkraniPreview() {
    val navController = rememberNavController()
    KayitEkrani(navController = navController)
}