package com.example.my.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.Color
import com.example.my.Routes



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnketSayfasi(navController: NavHostController) {
    val sorular = listOf(
        "Hocanın ders anlatım şekli anlaşılır mı?",
        "Ders materyalleri yeterli ve güncel mi?",
        "Quiz yapıyor mu?",
        "Ders materyallerini paylasiyor mu?",
        "Dersleri genelde proje bazli mi isliyor?",
        "Hoca çan uyguluyor mu?",
        "Cok fazla ödev veriyor mu?",
        "Hoca yoklama alıyor mu?"
    )
    val koyu = Color(0xFF424569)
    val cevaplar = remember { mutableStateOf(Array(sorular.size) { false }) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hocalar İçin Geri Bildirim Anketi",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentWidth(Alignment.CenterHorizontally)
                )
                    Spacer(Modifier.height(15.dp)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Routes.Anasayfa.route) }) {
                        Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Geri")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {


            itemsIndexed(sorular) { index, soru ->
                SoruItem(soru = soru, cevaplar = cevaplar, index = index)
                Spacer(Modifier.height(8.dp))
            }

            item {
                Button(
                    onClick = {
                        // Cevapları işle ve bir sonraki ekrana geç
                        navController.navigate("Hoca")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = ButtonDefaults.buttonColors(koyu)
                ) {
                    Text("Gönder")
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}


@Composable
fun SoruItem(soru: String, cevaplar: MutableState<Array<Boolean>>, index: Int) {
    val mavi = Color(0xFF424569)
    val sari = Color(0xFFE49D55)

    val evetSecildi = remember { mutableStateOf(false) }
    val hayirSecildi = remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            soru,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Button(
                onClick = {
                    evetSecildi.value = !evetSecildi.value
                    hayirSecildi.value = false
                    cevaplar.value[index] = evetSecildi.value
                },
                colors = ButtonDefaults.buttonColors(if (evetSecildi.value) sari else mavi),
                modifier = Modifier.weight(1f)
            ) {
                Text("Evet")
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    hayirSecildi.value = !hayirSecildi.value
                    evetSecildi.value = false
                    cevaplar.value[index] = !hayirSecildi.value
                },
                colors = ButtonDefaults.buttonColors(if (hayirSecildi.value) sari else mavi),
                modifier = Modifier.weight(1f)
            ) {
                Text("Hayır")
            }
        }
    }
}



@Preview(showBackground = true)
@Composable
fun AnketSayfasiPreview() {
    val navController = rememberNavController()
    AnketSayfasi(navController)
}