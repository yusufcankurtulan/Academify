package com.example.my.tabs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.my.R
import com.example.my.Routes




@Composable
fun WelcomeScreen(navController: NavHostController) {
    val mavi = Color(0xFF8186B5)
    val koyu = Color(0xFF181831)

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.karsilama),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.weight(1f)) // Boşluk ekleniyor

            Button(
                onClick = { navController.navigate(Routes.Kayit.route) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(45.dp)
                    .padding(horizontal = 50.dp),
                colors = ButtonDefaults.buttonColors( mavi)
            ) {
                Text("Hesap oluştur", fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.height(16.dp)) // Butonlar arasına boşluk ekleniyor

            Button(
                onClick = { navController.navigate(Routes.Giris.route) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(45.dp)
                    .padding(horizontal = 50.dp),
                colors = ButtonDefaults.buttonColors( koyu)
            ) {
                Text("Oturum aç", fontSize = 22.sp)
            }
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}



@Preview
@Composable
fun WelcomeScreenPreview() {
    // Önizleme için bir Navigation Controller oluşturabilirsiniz, burada varsayılan bir NavController kullandım
    val navController = rememberNavController()

    WelcomeScreen(navController = navController)
}


