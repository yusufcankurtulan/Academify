package com.example.my.tabs

import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.my.Routes
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.rememberNavController
import com.example.my.R
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun GirisEkrani(navController: NavHostController) {
    var hatirla by remember { mutableStateOf(false) }
    var sifreGorunur by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    val sifre = remember { mutableStateOf(TextFieldValue()) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    val mavi  = Color(0xFF8186B5)
    val sari = Color(0xFFE49D55)

    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.oturum),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Spacer(modifier = Modifier.height(100.dp))


            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                leadingIcon = { Icon(imageVector = Icons.Filled.Mail, contentDescription = null,tint = mavi) },
                label = { Text("E-mail") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                isError = !isValidEmail(email),
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Next
                ),
                singleLine = true,
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                )
            )


            OutlinedTextField(
                label = { Text("Şifre") },
                value = sifre.value,
                onValueChange = { sifre.value = it },
                visualTransformation = if (sifreGorunur) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                singleLine = true,
                keyboardActions = KeyboardActions(
                    onDone = { keyboardController?.hideSoftwareKeyboard() }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )

            // "Beni Hatırla" Seçeneği ve Şifremi Unuttum Butonu aynı satırda

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = hatirla,
                        onCheckedChange = { hatirla = it },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = CheckboxDefaults.colors(
                            checkedColor = mavi, // Seçili durumda olan renk
                            uncheckedColor = mavi // Seçili olmayan durumda olan renk
                        )
                    )
                    Text(
                        "Beni Hatırla",
                        fontSize = 14.sp,
                        color = mavi // Metin rengi
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    ClickableText(
                        text = AnnotatedString("Şifremi Unuttum"),
                        onClick = { navController.navigate(Routes.KayitSifremEkrani.route) },
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Default,
                            color = mavi
                        ),
                        modifier = Modifier
                            .padding(top = 15.dp)
                    )
                }
            }


            Button(
                onClick = {
                    navController.navigate(Routes.Anasayfa.route)
                },
                colors = ButtonDefaults.buttonColors(
                    mavi,
                    contentColor = Color.White // Buton metin rengi
                ),

                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(horizontal = 8.dp),
            ) {
                Text("Oturum Aç", fontSize = 22.sp)
            }


            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp,horizontal = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically // Dikey hizalama
            ) {
                val separator = "\u2014" // Uzun çizgi karakteri

                Spacer(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .width(50.dp) // Genişlik ayarı
                        .background(color = Color.LightGray) // Arka plan rengi
                )

                Text(
                    text = "Veya",
                    color = Color.LightGray,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Default,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .width(50.dp) // Genişlik ayarı
                        .background(color = Color.LightGray) // Arka plan rengi
                )
            }


            val token = stringResource(R.string.web_client_id)
            val launcherNav = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult()
            ) {
                navController.navigate(Routes.Anasayfa.route)
            }
            val launcher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult(),
            ) {
                val task =
                    try {
                        val account = GoogleSignIn.getSignedInAccountFromIntent(it.data)
                            .getResult(ApiException::class.java)
                        val credential = GoogleAuthProvider.getCredential(account.idToken!!, null)
                        FirebaseAuth.getInstance().signInWithCredential(credential)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    navController.navigate(Routes.Anasayfa.route)
                                }
                            }
                    } catch (e: ApiException) {
                        Log.w("TAG", "Google Sign in Failed", e)
                    }
            }
            Button(
                onClick = {
                    val gso = GoogleSignInOptions
                        .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(token)
                        .requestEmail()
                        .build()
                    val googleSignInClient = GoogleSignIn.getClient(context, gso)
                    launcher.launch(googleSignInClient.signInIntent)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)


            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.google),
                        contentDescription = "Google Icon",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(
                        modifier = Modifier.width(8.dp)
                    )
                    Text(text = "Google İle Devam Et ", color = Color.Black, fontSize = 22.sp)
                }
            }
        }
    }

}

private fun isValidEmail(email: String): Boolean {
    val emailRegex = "^[A-Za-z](.*)(@std.yeditepe.edu.tr)\$"
    return email.matches(emailRegex.toRegex())
}
@Preview(showSystemUi = true)
@Composable
fun Screen(){
    val navController = rememberNavController()
    GirisEkrani(navController)
}