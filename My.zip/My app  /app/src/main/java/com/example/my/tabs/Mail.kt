package com.example.my.tabs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.my.R
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Mail(navController: NavHostController) {
    var kod by remember { mutableStateOf(Array(4) { "" }) }
    var showErrorSnackbar by remember { mutableStateOf(false) }
    val sarı = Color(0xFFE49D55)
    val koyu = Color(0xFF181831)

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.eposta),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.weight(1f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 50.dp),
                horizontalArrangement = Arrangement.SpaceBetween

            ) {
                val textFieldCount = 4
                for (i in 0 until textFieldCount) {
                    OutlinedTextField(
                        value = kod[i],
                        onValueChange = { yeniDeger ->
                            if (yeniDeger.length <= 1) {
                                val guncellenmisKod = kod.clone()
                                guncellenmisKod[i] = yeniDeger
                                kod = guncellenmisKod
                            }
                        },

                        modifier = Modifier
                            .padding(horizontal = 10.dp)
                            .weight(1f)
                            .fillMaxWidth()
                            .background(koyu),
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            textColor = Color.White
                        )

                    )
                }
            }

            Spacer(modifier = Modifier.height(96.dp))

            // "Tamam" Butonu
            Button(onClick = {
                // Girilen kodun doğruluğunu kontrol et
                val girilenKod = kod.joinToString("")
                if (girilenKod == "1234") { // "1234" doğru kodla değiştirilmelidir
                    navController.navigate(Routes.Giris.route) // Kod doğruysa bir sonraki ekrana geç
                } else {
                    showErrorSnackbar = true // Kod yanlışsa Snackbar göster
                }
            },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(45.dp)
                    .padding(horizontal = 100.dp),

                colors = ButtonDefaults.buttonColors( sarı) // Renk ayarı burada yapılıyor
            ) {
                Text("Gönder", fontSize = 22.sp)
            }


            // Snackbar
            if (showErrorSnackbar) {
                Snackbar(
                    modifier = Modifier.padding(6.dp),
                    action = {
                        TextButton(onClick = { showErrorSnackbar = false }) {

                        }
                    },
                ) {
                    Text("Yanlış kod. Lütfen tekrar deneyin.",
                        textAlign = TextAlign.Center )
                }
            }
            Spacer(modifier = Modifier.height(110.dp))
        }
    }
}
@Preview
@Composable
fun MailPreview() {
    MaterialTheme {
        Mail(navController = rememberNavController())
    }
}
