package com.example.my.tabs
//Bu sayfa şifremi unuttum kısmı
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.my.R
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KayitSifremEkrani(navController: NavHostController) {
    var email by remember { mutableStateOf("") }
    val mavi  = Color(0xFF8186B5)
    val sarı = Color(0xFFE49D55)
    val koyu = Color(0xFF181831)

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.sifre),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.weight(1f))
            // Email Adresi Girişi
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("E-mail", color = Color.White) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(koyu),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.White, // İçindeki metin rengini beyaz yapmak için
                    focusedBorderColor = koyu, // Odaklandığında çizgi rengi
                    unfocusedBorderColor = koyu)
            )

            Spacer(modifier = Modifier.height(60.dp))
            // "Kod Gönder" Butonu
            Button(
                onClick = { navController.navigate(Routes.KodEkrani.route) },

            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .padding(horizontal = 100.dp),

            colors = ButtonDefaults.buttonColors( sarı) // Renk ayarı burada yapılıyor
            ){
                Text("Gönder", fontSize = 22.sp)
            }


            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
