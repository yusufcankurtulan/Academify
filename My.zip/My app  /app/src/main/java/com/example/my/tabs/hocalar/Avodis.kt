package com.example.my.tabs.hocalar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.my.Routes

@Composable
fun AVODİSDetailsScreen(navController: NavHostController) {
// Kurgusal veri örnekleri
    val instructorName = "Avodis Simon Hacınlıyan"
    val instructorTitle = " Prof. Dr."
    val instructorTask = "Akademisyen"
    val instructorEmail = "ahacinliyan@yeditepe.edu.tr"
    val lessonDetails = "Ders işleyiş şekli hakkında bilgi..."
    val checkBoxItems = listOf(
        "Çan uyguluyor mu? ",
        "Proje veriyor mu?",
        "Quiz yapıyor mu?",
        "Ödev veriyor mu?",
        "Yoklama konusunda katı mı?"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(end = 8.dp)
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back Arrow Icon"
                )
            }
            // İnstructor Adı
            Text(
                text = instructorName,
                style = MaterialTheme.typography.titleLarge
            )
        }
        // İnstructor Ünvanı
        Text(
            text = instructorTitle,
            style = MaterialTheme.typography.bodyMedium
        )

        // İnstructor Görevi
        Text(
            text = instructorTask,
            style = MaterialTheme.typography.bodyMedium
        )

        // İnstructor Email
        Text(
            text = "Email: $instructorEmail",
            style = MaterialTheme.typography.bodyMedium
        )

        // Ders İşleyiş Detayları
        Text(
            text = lessonDetails,
            style = MaterialTheme.typography.bodyMedium
        )

        // Checkbox'lar
        Text(
            text = "Checkboxes:",
            style = MaterialTheme.typography.bodyMedium
        )

        // Checkbox listesi oluşturma
// Checkbox listesi oluşturma
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(checkBoxItems.size) { index ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        // Checkbox veya metin öğesine tıklanma durumu
                        // Buraya gerekli işlemleri ekleyebilirsiniz
                    }
                ) {
                    Text(
                        text = checkBoxItems[index],
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Checkbox(
                        checked = false, // Burada checkbox durumu belirtilmeli
                        onCheckedChange = { /* Checkbox durumunun değiştiği zaman yapılacak işlemler */ },
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.Center // Centering horizontally
        ) {
            Button(
                onClick = {
                    navController.navigate(Routes.AnketSayfasi.route)
                }

            ) {
                Text("Anket ")
            }

        }

    }
}
