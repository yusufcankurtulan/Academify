package com.example.my.tabs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SubdirectoryArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonSearchScreen(navController: NavHostController) {
    var keyword by remember { mutableStateOf("") }
    val lessons = remember { listOf("Acm 431", "Acm 365","Acm 369" ,"Comp 301", "Comp 303"
        ,"Vcd 321","Vcd 421","Vcd 471","Vcd 372") }

    val filteredLessons = lessons.filter { it.contains(keyword, ignoreCase = true) }

    val backgroundColor = Color.White

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(end = 8.dp)
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back Arrow Icon"
                )
            }

            Text(
                text = "Dersler",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = keyword,
            onValueChange = { keyword = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            label = { Text("Hoca adı ara") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Icon"
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done
            ),
        )

        LessonList(lessons = filteredLessons,
            navController = navController,
            keyword = keyword,
            backgroundColor = backgroundColor)

    }
}


@Composable
fun LessonList(
    lessons: List<String>,
    navController: NavHostController,
    keyword: String,
    backgroundColor: Color
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .background(backgroundColor)
            .padding(8.dp)
    ) {
        val filteredLessons =
            if (keyword.isNotEmpty()) lessons.filter { it.contains(keyword, ignoreCase = true) } else lessons
        items(filteredLessons) { lesson ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable {
                        navigateToRoute1(navController, lesson  )
                    }
            ) {
                if (keyword.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Default.SubdirectoryArrowRight,
                        contentDescription = "Arrow Icon",
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                Text(
                    text = lesson,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 8.dp),
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}




fun navigateToRoute1(navController: NavHostController, lesson: String) {
    when (lesson) {
        "Acm 365" -> navController.navigate(Routes.ACM365.route)
        "Acm 369" -> navController.navigate(Routes.ACM369.route)
        "Acm 431" -> navController.navigate(Routes.ACM431.route)
        "Comp 301" -> navController.navigate(Routes.COMP301.route)
        "Comp 303" -> navController.navigate(Routes.COMP303.route)
        "Vcd 321" -> navController.navigate(Routes.VCD321.route)
        "Vcd 372" -> navController.navigate(Routes.VCD372.route)
        "Vcd 421" -> navController.navigate(Routes.VCD421.route)
        "Vcd 471" -> navController.navigate(Routes.VCD471.route)
        else -> {
            /* Diğer durumlar için gerekli işlemleri yapabilirsiniz */
        }
    }
}