package com.example.my.tabs

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.my.Routes
import com.example.my.tabs.dersler.ACM365DetailsScreen
import com.example.my.tabs.dersler.ACM369DetailsScreen
import com.example.my.tabs.dersler.ACM431DetailsScreen
import com.example.my.tabs.dersler.COMP301DetailsScreen
import com.example.my.tabs.dersler.COMP303DetailsScreen
import com.example.my.tabs.dersler.VCD321DetailsScreen
import com.example.my.tabs.dersler.VCD372DetailsScreen
import com.example.my.tabs.dersler.VCD421DetailsScreen
import com.example.my.tabs.dersler.VCD471DetailsScreen
import com.example.my.tabs.hocalar.ALİDetailsScreen
import com.example.my.tabs.hocalar.AVODİSDetailsScreen
import com.example.my.tabs.hocalar.ENGİNDetailsScreen
import com.example.my.tabs.hocalar.GÜLDetailsScreen
import com.example.my.tabs.hocalar.HACIDetailsScreen
import com.example.my.tabs.hocalar.MERVEDetailsScreen
import com.example.my.tabs.hocalar.NEDADetailsScreen
import com.example.my.tabs.hocalar.TUNADetailsScreen




@Composable
fun AnaEkran(){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.SplashScreen.route) {
        composable(Routes.SplashScreen.route) {
            SplashScreen(navController = navController)
        }
        composable(Routes.WelcomeScreen.route) {
            WelcomeScreen(navController = navController)
        }
        composable(Routes.Giris.route) {
            GirisEkrani(navController = navController)
        }
        composable(Routes.Kayit.route) {
            KayitEkrani(navController = navController)
        }
        composable(Routes.KayitSifremEkrani.route) {
            KayitSifremEkrani(navController = navController)
        }
        composable(Routes.YeniSifreEkrani.route) {
            YeniSifreEkrani(navController = navController)
        }
        composable(Routes.Mail.route) {
            Mail(navController = navController)
        }
        composable(Routes.ACM365.route) {
            ACM365DetailsScreen(navController = navController)
        }
        composable(Routes.ACM369.route) {
            ACM369DetailsScreen(navController = navController)
        }
        composable(Routes.ACM431.route) {
            ACM431DetailsScreen(navController = navController)
        }
        composable(Routes.COMP301.route) {
            COMP301DetailsScreen(navController = navController)
        }
        composable(Routes.COMP303.route) {
            COMP303DetailsScreen(navController = navController)
        }

        composable(Routes.VCD321.route) {
            VCD321DetailsScreen(navController = navController)
        }
        composable(Routes.VCD372.route) {
            VCD372DetailsScreen(navController = navController)
        }
        composable(Routes.VCD421.route) {
            VCD421DetailsScreen(navController = navController)
        }
        composable(Routes.VCD471.route) {
            VCD471DetailsScreen(navController = navController)
        }
        composable(Routes.Anasayfa.route) {
            MainScreen(navController = navController)
        }
        composable(Routes.KodEkrani.route) {
            KodEkrani(navController = navController)
        }
        composable(Routes.Ders.route) {
            LessonSearchScreen(navController = navController)
        }
        composable(Routes.Hoca.route) {
            TeacherSearchScreen(navController = navController)
        }
        composable(Routes.ENGİN.route) {
            ENGİNDetailsScreen(navController = navController)
        }
        composable(Routes.ALİ.route) {
            ALİDetailsScreen(navController = navController)
        }
        composable(Routes.HACI.route) {
            HACIDetailsScreen(navController = navController)
        }
        composable(Routes.AVODİS.route) {
            AVODİSDetailsScreen(navController = navController)
        }
        composable(Routes.GÜL.route) {
            GÜLDetailsScreen(navController = navController)
        }
        composable(Routes.NEDA.route) {
            NEDADetailsScreen(navController = navController)
        }
        composable(Routes.MERVE.route) {
            MERVEDetailsScreen(navController = navController)
        }
        composable(Routes.TUNA.route) {
            TUNADetailsScreen(navController = navController)
        }
        composable(Routes.Cikis.route) {
            GirisEkrani(navController = navController)
        }
        composable(Routes.AnketSayfasi.route) {
            AnketSayfasi(navController = navController)
        }
        composable(Routes.Favori.route) {
            FavoriEkrani(navController = navController)
        }
    }
}




