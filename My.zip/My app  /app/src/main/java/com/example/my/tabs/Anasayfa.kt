package com.example.my.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavHostController) {
    var isMenuOpen by remember { mutableStateOf(false) }
    var isAnnouncementOpen by remember { mutableStateOf(false) }

    Column {

        TopAppBar(
            title = { Text("Ana Ekran") },
            navigationIcon = {
                IconButton(onClick = { isMenuOpen = true }) {
                    Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu")
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (isMenuOpen) {
            SideMenu(navController, onClose = { isMenuOpen = false })
        }
        AnnouncementHeader(onClick = { isAnnouncementOpen = !isAnnouncementOpen })
        if (isAnnouncementOpen) {
            AnnouncementList()
        }

    }
}

@Composable
fun AnnouncementHeader(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        Text(
            text = "Duyurular",
            modifier = Modifier
                .align(Alignment.Center)
                .padding(vertical = 30.dp)
                .clickable(onClick = onClick)
        )
    }
}

@Composable
fun AnnouncementList() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(16.dp)
        ) {
            Text("Duyuru 1")
            Text("Duyuru 2")
            Text("Duyuru 3")
        }
    }
}


@Composable
fun SideMenu(navController: NavController, onClose: () -> Unit) {
    var selectedItem by remember { mutableStateOf<String?>(null) }



    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Gray.copy(alpha = 0.5f))
            .clickable { onClose() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .width(200.dp)
                .background(Color.White)
                .padding(5.dp)
        ) {

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)

            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Ad soyad")
            }


            Spacer(modifier = Modifier.height(50.dp))

            MenuItem("Dersler") {
                selectedItem = "Dersler"
                navController.navigate(Routes.Ders.route)
            }

            MenuItem("Hocalar") {
                selectedItem = "Hocalar"
                navController.navigate(Routes.Hoca.route)
            }
            MenuItem("Sohbet Odaları") {
                selectedItem = "Sohbet Odaları"
                navController.navigate("Option3Screen")
            }
            MenuItem("Favoriler") {
                selectedItem = "Favoriler"
                navController.navigate(Routes.Favori.route)

            }


            Spacer(modifier = Modifier.weight(1f))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable {
                        selectedItem = "Çıkış Yap"
                        navController.navigate(Routes.WelcomeScreen.route)
                        performLogout()
                    }
            ) {
                Icon(
                    imageVector = Icons.Filled.ExitToApp,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Çıkış Yap")
            }



        }
    }
}



fun performLogout() {
    // Kullanıcının oturumunu kapatma, kullanıcı verilerini temizleme veya
    // çıkış işlemine yönelik diğer gereklilikleri bu fonksiyon içinde uygulayabilirsiniz.
    // Örneğin, kullanıcı verilerini temizlemek veya giriş ekranına geri dönmek gibi işlemler yapılabilir.
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable(onClick = onClick)
    )
}