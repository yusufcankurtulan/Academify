package com.example.my.tabs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController



@Composable
fun FavoriEkrani(navController: NavHostController ) {
    val favoriDersler = FavoriManager.getFavoriDersler()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(end = 8.dp)
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back Arrow Icon"
                )
            }

            Text(
                text = "Favori Dersler",
                modifier = Modifier.padding(bottom = 8.dp),
                style = MaterialTheme.typography.titleLarge
            )
        }

        if (favoriDersler.isNotEmpty()) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(favoriDersler.size) { index ->
                    FavoriDersItem(favoriDersler[index])
                }
            }
        } else {
            Text(
                text = "Henüz favori ders yok",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}




@Composable
fun FavoriDersItem(dersAdi: String) {
    Text(
        text = dersAdi,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    )
}

object FavoriManager {
    private val favoriDersler = mutableSetOf<String>()

    // Dersi favoriye ekle
    fun addFavoriDers(dersKodu: String) {
        favoriDersler.add(dersKodu)
        // Burada favori dersler listesini tercihler veya veritabanı kullanarak güncelleyebilirsiniz
    }

    // Dersi favoriden kaldır
    fun removeFavoriDers(dersKodu: String) {
        favoriDersler.remove(dersKodu)
        // Burada favori dersler listesini tercihler veya veritabanı kullanarak güncelleyebilirsiniz
    }

    // Ders favori mi kontrolü
    fun isDersFavori(dersKodu: String): Boolean {
        return favoriDersler.contains(dersKodu)
    }

    // Favori dersleri al
    fun getFavoriDersler(): List<String> {
        return favoriDersler.toList()
    }
}
