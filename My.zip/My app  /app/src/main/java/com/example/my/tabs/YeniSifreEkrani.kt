package com.example.my.tabs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.my.R
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YeniSifreEkrani(navController: NavHostController) {
    var yeniSifre by remember { mutableStateOf("") }
    var yeniSifreTekrar by remember { mutableStateOf("") }
    var sifreGorunur1 by remember { mutableStateOf(false) }
    var sifreGorunur2 by remember { mutableStateOf(false) }
    val sarı = Color(0xFFE49D55)
    val beyaz = Color(0xFFFFFFFF)
    val koyu = Color(0xFF181831)
    var showErrorSnackbar by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.sifre),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.weight(1f))
            // Yeni Şifre Girişi
            OutlinedTextField(
                value = yeniSifre,
                onValueChange = { yeniSifre = it },
                label = { Text("Yeni Şifre", color = Color.White) },
                visualTransformation = if (sifreGorunur1) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                trailingIcon = {
                    val image =
                        if (sifreGorunur1) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (sifreGorunur1) "Şifreyi Gizle" else "Şifreyi Göster"
                    IconButton(onClick = { sifreGorunur1 = !sifreGorunur1 }) {
                        Icon(imageVector = image, description,tint = beyaz)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(koyu),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.White, // İçindeki metin rengini beyaz yapmak için
                    focusedBorderColor = koyu, // Odaklandığında çizgi rengi
                    unfocusedBorderColor = koyu)
            )

            // Yeni Şifre Tekrar Girişi
            OutlinedTextField(
                value = yeniSifreTekrar,
                onValueChange = { yeniSifreTekrar = it },
                label = { Text("Yeni Şifre Tekrar", color = Color.White) },
                visualTransformation = if (sifreGorunur2) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                trailingIcon = {
                    val image =
                        if (sifreGorunur2) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (sifreGorunur2) "Şifreyi Gizle" else "Şifreyi Göster"
                    IconButton(onClick = { sifreGorunur2 = !sifreGorunur2 }) {
                        Icon(imageVector = image, description,tint = beyaz)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(koyu),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    textColor = Color.White,
                    focusedBorderColor = koyu,
                    unfocusedBorderColor = koyu)
            )
            Spacer(modifier = Modifier.height(16.dp))


            Button(onClick = {
                if (yeniSifre == yeniSifreTekrar && yeniSifre.isNotBlank()) {
                    // Yeni şifre kaydedilebilir
                    // Örneğin: Şifreyi bir veritabanına kaydetme işlemi gerçekleştirilebilir
                    navController.navigate(Routes.Giris.route)
                } else {
                    showErrorSnackbar = true

                }
            }, modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .padding(horizontal = 100.dp),

                colors = ButtonDefaults.buttonColors( sarı)
            )

            {
                Text("Gönder", fontSize = 22.sp)
            }

            if (showErrorSnackbar) {
                Snackbar(
                    modifier = Modifier
                        .padding(6.dp)
                         ,
                    action = {
                        TextButton(onClick = { showErrorSnackbar = false }) {

                        }
                    },
                ) {
                    Text("Şifreler eşleşmiyor tekrar deneyiniz.",
                        textAlign = TextAlign.Center )
                }
            }
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
