package com.example.my.tabs.dersler

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun COMP301DetailsScreen(navController: NavHostController) {
    // Kurgusal veri örnekleri
    val lessonCode = "COMP 301"
    val lessonTitle = "Yazılım Mimarisi ve Araçları"
    val lessonContent = "Dersin amacı, öğrencileri yazılım mimarlığı alanına tanıtmak, tasarım becerilerini geliştirmek ve soyut düşünme yeteneğini arttırmaktır. Bu dersi alan öğrenciler fonksiyonel ve fonksiyonel olmayan ihtiyaç analizi yapabilir ve yazılımın geliştirilmesi için gerekli yazılımı tasarlayıp geliştirebilir."
    val noteLink = "https://example.com/notes/comp301"
    val instructors = listOf("Engin Kandıran")
    var isStarred by remember { mutableStateOf(false) }
    val sarı = Color(0xFFE49D55)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween // Öğeler arasındaki boşluğu kullanarak hizalama sağlar
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back Arrow Icon"
                    )
                }

                // Ders kodu
                Text(
                    text = "$lessonCode",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }



            IconButton(
                onClick = {
                    isStarred = !isStarred
                },
                modifier = Modifier
                    .size(48.dp)
            ) {
                val iconTint = if (isStarred) sarı else Color.Unspecified

                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Star Icon",
                    tint = iconTint
                )
            }

        }
        //Ders Başlığı
        Text(
            text = "$lessonTitle",
            style = MaterialTheme.typography.titleMedium
        )

        // Ders içeriği
        Text(
            text = lessonContent,
            style = MaterialTheme.typography.bodyMedium
        )

        // Ders notu linki
        Text(
            text = "Notes: $noteLink",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Blue,
            modifier = Modifier.clickable {
                // Ders notu linkine tıklama işlevselliği
                // Örnek olarak tarayıcıda linki açabilirsiniz
                // Intent kullanılarak sayfa geçişi de sağlanabilir
            }
        )

        // Dersi veren hocalar
        Text(
            text = "Instructors:",
            style = MaterialTheme.typography.bodyMedium
        )

        instructors.forEach { instructor ->
            Text(
                text = "- $instructor",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.clickable {
                    // Öğretmenin adına tıklama işlevselliği
                    when (instructor) {
                        "Engin Kandıran" -> {
                            navController.navigate("ENGİN")
                        }
                    }
                }
            )
        }
    }
}