package com.example.my.tabs


import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SubdirectoryArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.my.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherSearchScreen(navController: NavHostController) {
    var keyword by remember { mutableStateOf("") }
    val teachers = remember {
        listOf(
            "Engin Kandıran", "Ali Cihan Keleş", "Hacı Ahmet Yıldırım", "Avodis Simon Hacınlıyan",
            "Gül Bakan", "Neda Üçer", "Merve Çaşkurlu", "Tuna Oktay"
        )
    }
    val filteredTeachers = teachers.filter { it.contains(keyword, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(end = 8.dp)
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back Arrow Icon"
                )
            }

            Text(
                text = "Akademik Kadro",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = keyword,
            onValueChange = { keyword = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            label = { Text("Hoca adı ara") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Icon"
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done
            ),
        )

        TeacherList(teachers = filteredTeachers, navController = navController, keyword = keyword)
    }
}

@Composable
fun TeacherList(teachers: List<String>, navController: NavHostController, keyword: String) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.LightGray)
            .padding(8.dp)
    ) {
        val filteredTeachers = if (keyword.isNotEmpty()) teachers.filter { it.contains(keyword, ignoreCase = true) } else teachers
        items(filteredTeachers) { teacher ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable {
                        navigateToRoute(navController, teacher)
                    }
            ) {
                if (keyword.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Default.SubdirectoryArrowRight,
                        contentDescription = "Arrow Icon",
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                Text(
                    text = teacher,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 8.dp),
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}


fun navigateToRoute(navController: NavHostController, teacher: String) {
    when (teacher) {
        "Engin Kandıran" -> navController.navigate(Routes.ENGİN.route)
        "Ali Cihan Keleş" -> navController.navigate(Routes.ALİ.route)
        "Hacı Ahmet Yıldırım" -> navController.navigate(Routes.HACI.route)
        "Avodis Simon Hacınlıyan" -> navController.navigate(Routes.AVODİS.route)
        "Gül Bakan" -> navController.navigate(Routes.GÜL.route)
        "Neda Üçer" -> navController.navigate(Routes.NEDA.route)
        "Merve Çaşkurlu" -> navController.navigate(Routes.MERVE.route)
        "Tuna Oktay" -> navController.navigate(Routes.TUNA.route)
        else -> {
            /* Diğer durumlar için gerekli işlemleri yapabilirsiniz */
        }
    }
}